# Risk Disclosure

Trading leveraged products involves substantial risk and is not suitable for every investor. Historical tests are not a guarantee of future results. Use sensible position sizing, widen buffers on volatile instruments, and forward-test on demo before going live.
