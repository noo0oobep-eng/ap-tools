AP AlphaLog AI – MT5 Trade Journal Engine
=========================================

Version: 1.00
Platform: MetaTrader 5 (MT5)
Type: Non-trading Expert Advisor (journal/logger only)

Overview
--------
AP AlphaLog AI is a non-trading MT5 Expert Advisor that automatically logs 
your closed trades into a compact .alog file. Those .alog files can then be 
uploaded to the AP AlphaLog AI web analyser for detailed performance 
analysis and AI-generated feedback.

The EA does NOT place trades, manage positions, or modify orders. It simply 
watches your account and records closed trades.


What’s included in this package
-------------------------------
1) AP_AlphaLog_AI_MT5.ex5
   - The MT5 Expert Advisor (journal engine).

2) AP_AlphaLog_AI_Readme.txt
   - This setup and usage guide.


Quick start (3 steps)
---------------------
1) Install the EA into MT5.
2) Attach it to ONE chart (any symbol/timeframe) and leave it running.
3) After you have some closed trades, upload the generated .alog file to:
   https://aptradingtools.com/alphalog/


1. Installation in MT5
----------------------

1. Close MetaTrader 5 if it is running.

2. Copy the EA file:
   AP_AlphaLog_AI_MT5.ex5

   into your MT5 "Experts" folder. The typical path is:

   - Open MT5
   - Go to: File -> Open Data Folder
   - Then navigate to: MQL5 -> Experts
   - Paste AP_AlphaLog_AI_MT5.ex5 into that Experts folder.

3. Restart MetaTrader 5.

4. In MT5, open the Navigator:
   - View -> Navigator (or press Ctrl+N)
   - Under "Expert Advisors", you should see:
     AP_AlphaLog_AI_MT5


2. Attaching the EA to a chart
------------------------------

1. Open any chart (for example XAUUSD H1).  
   The symbol and timeframe do not matter for logging; the EA just needs 
   to be attached somewhere in the terminal.

2. Drag AP_AlphaLog_AI_MT5 from the Navigator onto that chart
   OR right-click it and select "Attach to a chart".

3. In the EA settings window:

   - On the "Common" tab:
     * Allow Algo Trading: ENABLED
     * Allow DLL imports: NOT REQUIRED (leave disabled if unsure)
     * Allow modification of Signals settings: off (optional)

   - On the "Inputs" tab:
     * Adjust any inputs you want (if provided in your build).
       Typical inputs might include:
       - Log file prefix
       - Whether to include commissions/swaps, etc.

4. Ensure Algo Trading is turned ON in MT5:
   - The "Algo Trading" button at the top of MT5 should be green.

5. Once running, you should see a small smiley or active EA icon in the 
   top-right of the chart where it is attached.


3. How the logging works
------------------------

- The EA listens for closed positions on your MT5 account.
- Whenever a trade closes, the EA writes a compressed, encoded record into 
  an .alog file.

File location
-------------
By default, the .alog files are stored in your MT5 data folder, usually:

  MQL5\Files\

Typical filename format:

  AP_AlphaLog_AI_XXXXXXXX_YYYYMM.alog

Where:
- XXXXXXXX is an internal or account-related ID.
- YYYYMM is the year and month.

You can view the Files folder by:
- In MT5, go to: File -> Open Data Folder
- Then open: MQL5 -> Files


4. Using the AP AlphaLog AI web analyser
----------------------------------------

Once you have some closed trades logged, you can generate a report:

1. Locate the .alog file:
   - From MT5: File -> Open Data Folder
   - Go to: MQL5 -> Files
   - Find the latest: AP_AlphaLog_AI_*.alog file

2. Go to the web analyser:
   - Open your browser and visit:
     https://aptradingtools.com/alphalog/

3. On that page:
   - Click "Choose file" / "Browse"
   - Select your .alog file (e.g. AP_AlphaLog_AI_52609556_202511.alog)
   - Click the "Analyse (preview)" button

4. The page will show:
   - Preview summary (trades, winrate, net P/L, R-multiple stats)
   - Performance by symbol table

5. To get AI-written analysis and advice:
   - Click the "Generate AI Analysis & Advice" button
   - The page will display:
     * Strengths
     * Weaknesses / key issues
     * Concrete next-step plan for your trading

6. Advanced breakdowns (equity curve, session performance, day-of-week 
   stats, and local stat-based notes) are revealed after the AI analysis 
   is generated, so it feels like part of the full report.


5. Recommended usage
--------------------

- Attach AP_AlphaLog_AI_MT5 to ONE chart per MT5 account.
- Keep the chart and MT5 running during your trading sessions so that 
  closed trades are reliably logged.
- The EA is safe to use on live or demo accounts; it does not send orders 
  or change positions.

- For best results:
  * Run it continuously for at least a few weeks to build a meaningful 
    trade history.
  * Upload a fresh .alog file to the analyser once or twice a week to 
    review your performance.
  * Pay attention to:
    - Symbols where you are consistently profitable.
    - Sessions (London, NY, etc.) where you perform better or worse.
    - R-multiple behaviour (how far winners run vs. how large losers are).


6. Notes about pricing and access
---------------------------------

- The AP AlphaLog AI MT5 Trade Journal Engine is currently provided free 
  from AP Trading Tools.

- The AP AlphaLog AI web analyser at:
  https://aptradingtools.com/alphalog/
  currently provides:
  * Free on-screen preview.
  * AI-generated analysis and advice (at the time of writing).
  Future pricing or limits may be introduced; please check the site for 
  the latest details.


7. Troubleshooting
------------------

No .alog file appears:
- Check that AP_AlphaLog_AI_MT5 is actually running (smiley/active icon).
- Ensure "Algo Trading" is enabled in MT5.
- Confirm there have been closed trades after the EA was attached.
- Check the path: File -> Open Data Folder -> MQL5 -> Files.

Web analyser says "No trades found":
- Make sure you selected the correct .alog file.
- Check that the log file is not empty and that trades have closed after 
  the EA started.

AI analysis errors:
- Occasionally the AI backend may be busy or rate-limited.
- If you see an error, wait a short time and try again.
- Make sure your internet connection is stable.

If issues persist, you can contact AP Trading Tools with:
- Your MT5 build number
- Broker name
- A sample .alog file (if you are comfortable sharing it)


8. Contact
----------

For updates, support, and additional tools:

AP Trading Tools  
Website: https://aptradingtools.com/  
(See the AP AlphaLog AI section for the latest info)
