# AP Previous Day Breakout – Resource Pack (v1.0)

**EA:** AP Previous Day Breakout (MT5) — version tag AP_PDB_v1.102

This pack contains ready-to-use **.set** presets and quick-start notes.

## Folders
- `presets/` → drop-in **.set** files for Strategy Tester or live.
- `docs/` → this README and FAQ/Changelog.

## How to apply a preset
1. Attach the EA to a chart (M5 recommended).
2. Click **Inputs → Load...** and choose a file from `/presets`.
3. Review `MaxSpreadPoints`, `FixedLots` or `RiskPercent` for your broker.
4. Save your chart as a template if you want (right-click → Template → Save).

## Preset overview
- **EURUSD_M5_Conservative.set**  
  Buffer 45, TP 1.5R, SLExtra 5, Trend EMA200/M15, Spread ≤ 40 pts, one set/day.

- **EURUSD_M5_FastTP.set**  
  Buffer 30, TP 1.25R, QuickExit 0.45R or 55 pts @ 12 min, Trend ON, Spread ≤ 40 pts.

- **XAUUSD_M5_Conservative.set**  
  Buffer 120, TP 1.5R, SLExtra 10, Trend ON, Spread ≤ 300 pts.

- **Tue-Thu_Tight_Spread.set**  
  Same as conservative but trades Tue–Thu only with tighter spread cap (≤ 30 pts).

- **Validator_Safe_Default.set**  
  Generous spread (1000 pts), CancelOppOnFill OFF, one set/day with 12h expiry.
  Use this when preparing Market uploads or very conservative testing.

## Notes
- Times are **server time**.
- For 5-digit FX symbols: 10 points = 1 pip.
- For metals/indices, adjust `MaxSpreadPoints` and buffers for the symbol tick size.
- The EA has **no DLLs**, a single **.ex5**, and is validator-safe.

## Quick troubleshooting
- **No trades?** Check trading window and day filters; verify PDH/PDL exist on your broker;
  confirm `MaxSpreadPoints` isn’t too tight.
- **Invalid stops?** Increase buffer or reduce `SLExtraPoints`; some brokers have large
  minimum stop distance.
- **Margin errors?** Lower `FixedLots` or `RiskPercent`.

## Change log
See `docs/Changelog.txt`.
